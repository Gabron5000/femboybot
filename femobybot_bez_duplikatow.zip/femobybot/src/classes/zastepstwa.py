#
#
#    ▄▄▄▄▄▄▄▄     ▄▄       ▄▄▄▄    ▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄      ▄▄▄▄    ▄▄▄▄▄▄▄▄ ▄▄      ▄▄    ▄▄
#    ▀▀▀▀▀███    ████    ▄█▀▀▀▀█   ▀▀▀██▀▀▀  ██▀▀▀▀▀▀  ██▀▀▀▀█▄  ▄█▀▀▀▀█   ▀▀▀██▀▀▀ ██      ██   ████
#        ██▀     ████    ██▄          ██     ██        ██    ██  ██▄          ██    ▀█▄ ██ ▄█▀   ████
#      ▄██▀     ██  ██    ▀████▄      ██     ███████   ██████▀    ▀████▄      ██     ██ ██ ██   ██  ██
#     ▄██       ██████        ▀██     ██     ██        ██             ▀██     ██     ███▀▀███   ██████
#    ███▄▄▄▄▄  ▄██  ██▄  █▄▄▄▄▄█▀     ██     ██▄▄▄▄▄▄  ██        █▄▄▄▄▄█▀     ██     ███  ███  ▄██  ██▄
#    ▀▀▀▀▀▀▀▀  ▀▀    ▀▀   ▀▀▀▀▀       ▀▀     ▀▀▀▀▀█▀▀  ▀▀         ▀▀▀▀▀       ▀▀     ▀▀▀  ▀▀▀  ▀▀    ▀▀
#                                                █▄▄
#

# Standardowe biblioteki
import asyncio
import contextlib
from datetime import datetime
from zoneinfo import ZoneInfo

# Zewnętrzne biblioteki
import aiohttp
import discord

# Wewnętrzne importy
from src.assets.ascii import ascii
from src.commands import (
	informacje,
	response,
	skonfiguruj,
	statystyki,
	test
)
from src.events import (
	join,
	remove
)
from src.handlers.configuration import konfiguracja
from src.handlers.logging import logiKonsoli
from src.tasks.statistics import sprawdźKoniecRoku
from src.tasks.updates import sprawdźAktualizacje

class Zastępstwa(discord.Client):
	"""
	Domyślne ustawienia, działania i operacje bota.

	Attributes:
		intents (discord.Intents): Uprawnienia (intencje) klienta Discord.
	"""

	def __init__(
		self,
		*,
		intents: discord.Intents
	) -> None:
		"""
		Inicjalizuje instancję klienta Zastępstwa.

		Args:
			intents (discord.Intents): Uprawnienia (intencje) klienta Discord.
		"""

		super().__init__(intents=intents)
		self.tree = discord.app_commands.CommandTree(self)

	async def setup_hook(self) -> None:
		"""
		Tworzy i konfiguruje sesję HTTP wywoływaną przy starcie bota.
		"""

		try:
			wersja = konfiguracja.get("wersja", "Brak danych")
			self.połączenieHTTP = aiohttp.ClientSession(
				timeout=aiohttp.ClientTimeout(total=10),
				headers={"User-Agent": f"Zastepstwa/{wersja} (https://github.com/kacpergorka/zastepstwa)"}
			)
		except Exception as e:
			logiKonsoli.critical(
				f"Nie udało się utworzyć sesji HTTP. Więcej informacji: {e}"
			)
			raise

	async def close(self) -> None:
		"""
		Bezpiecznie wyłącza bota, anuluje wszystkie zadania i zamyka sesję HTTP.
		"""

		for atrybut in ("aktualizacje", "koniecRoku"):
			zadanie = getattr(self, atrybut, None)

			if zadanie and not zadanie.done():
				try:
					zadanie.cancel()
				except Exception as e:
					logiKonsoli.exception(
						f"Wystąpił błąd podczas zatrzymywania zadania ({atrybut}). Więcej informacji: {e}"
					)

				with contextlib.suppress(asyncio.CancelledError, Exception):
					await zadanie

		if getattr(self, "połączenieHTTP", None):
			try:
				await self.połączenieHTTP.close()
			except Exception as e:
				logiKonsoli.exception(
					f"Wystąpił błąd podczas zamykania sesji HTTP. Więcej informacji: {e}"
				)
			finally:
				self.połączenieHTTP = None

		await super().close()

	async def on_ready(self) -> None:
		"""Synchronizuje komendy i uruchamia zadania cykliczne po zalogowaniu."""
		try:
			self.czas = datetime.now(ZoneInfo("Europe/Warsaw"))
			logiKonsoli.info(ascii)
			logiKonsoli.info(f"Zalogowano jako {self.user} (ID: {self.user.id}).")

			# Rejestruj komendy tylko globalnie. Wcześniej były kopiowane
			# również na każdy serwer, przez co Discord pokazywał duplikaty.
			try:
				await self.tree.sync()
				logiKonsoli.info("Zsynchronizowano komendy globalne.")
			except discord.DiscordException as e:
				logiKonsoli.exception(f"Nie udało się zsynchronizować komend globalnych: {e}")

			# Usuń stare kopie komend serwerowych utworzone przez poprzednią wersję.
			for identyfikator in konfiguracja.get("serwery", {}):
				gildia = discord.Object(id=int(identyfikator))
				try:
					self.tree.clear_commands(guild=gildia)
					await self.tree.sync(guild=gildia)
					logiKonsoli.info(f"Usunięto stare kopie komend serwerowych: {identyfikator}.")
				except discord.DiscordException as e:
					logiKonsoli.exception(f"Nie udało się wyczyścić komend serwerowych {identyfikator}: {e}")

			await self.change_presence(
				status=discord.Status.online,
				activity=discord.CustomActivity(name="Sprawdzam zastępstwa")
			)

			if not getattr(self, "aktualizacje", None) or self.aktualizacje.done():
				self.aktualizacje = asyncio.create_task(sprawdźAktualizacje(self))
			if not getattr(self, "koniecRoku", None) or self.koniecRoku.done():
				self.koniecRoku = asyncio.create_task(sprawdźKoniecRoku(self))
			logiKonsoli.info("Zadania cykliczne zostały uruchomione.")
		except Exception as e:
			logiKonsoli.exception(f"Błąd podczas inicjalizacji bota: {e}")

# Konfiguracja uprawnień bota
intents = discord.Intents.default()
bot = Zastępstwa(intents=intents)

# Import poleceń i eventów do synchronizacji
informacje.ustaw(bot)
response.ustaw(bot)
skonfiguruj.ustaw(bot)
statystyki.ustaw(bot)
test.ustaw(bot)
join.ustaw(bot)
remove.ustaw(bot)