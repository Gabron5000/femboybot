# FemobyBot / Bot-Hosting.net

## Uruchomienie
1. Wgraj zawartość ZIP-a do katalogu głównego serwera, tak aby `main.py`, `config.json`, `requirements.txt` i katalog `src` znajdowały się obok siebie.
2. W ustawieniach startup ustaw plik startowy na `main.py` (jeśli panel wymaga rozszerzenia, wpisz `main.py`).
3. Ustaw zmienną środowiskową `ZASTEPSTWA` na token bota Discord. Nie publikuj tokena ani nie wpisuj go na czacie.
4. Zapisz ustawienia i zrestartuj serwer.

Bot używa `python3`, więc w konsoli Linux nie uruchamiaj go komendą `py main.py`.

## Jeśli wiadomości nadal nie dochodzą
Sprawdź w `config.json`, czy dla każdego serwera `identyfikator-kanalu` jest ID istniejącego kanału tekstowego na tym samym serwerze. Bot musi być członkiem serwera i mieć na kanale uprawnienia `Wyświetlanie kanału` oraz `Wysyłanie wiadomości`.

Po uruchomieniu sprawdź konsolę. Powinny pojawić się wpisy o synchronizacji komend i uruchomieniu zadań cyklicznych. Komendy Discorda synchronizują się dla serwerów wymienionych w `config.json`.
